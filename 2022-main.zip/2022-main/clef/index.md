# SimpleText@CLEF-2022 Home

---

<meta http-equiv="refresh" content="2;url=en/" />
