# SimpleText@CLEF-2022 Contacts

[Home](./) | [Call for papers](./CFP) | [Important dates](./dates) | [Tasks](./tasks)  | [Tools](./tools) 
[Program](./program) | [Publications](./publications) | [Organisers](./organisers) | [Contact](./contact) | [CLEF-2023](https://simpletext-project.com/2023/clef)

---

Website: [http://simpletext-project.com/](http://simpletext-project.com/)

Twitter: [https://twitter.com/SimpletextW](https://twitter.com/SimpletextW)

Google group: [https://groups.google.com/g/simpletext](https://groups.google.com/g/simpletext)

CLEF website: [https://clef2022.clef-initiative.eu/index.php](https://clef2022.clef-initiative.eu/index.php)
 
Any question? Feel free to contact us: [contact@simpletext-project.com](mailto:contact@simpletext-project.com)
